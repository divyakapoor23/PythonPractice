def jungle():
    word = str(input())
    print(word)
    k = list(word.split(" "))
    for i in k:
        if i == 'Grr':
            print("Lion")
        elif i == 'Rawr':
            print("Tiger")
        elif i == 'Ssss':
            print("Snake")
        elif i == 'Chirp':
            print("Birds")
        else:
            print("Animal not identified")
    # easy solution
    w = str(input())
    w = w.replace("Ssss", "Snake")
    w = w.replace("Grr", "Lion")
    w = w.replace("Chirp", "Birds")
    w = w.replace("Rawr", "Tiger")