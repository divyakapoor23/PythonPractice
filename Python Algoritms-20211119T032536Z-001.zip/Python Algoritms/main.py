# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.
import math
def print_hi():
    # Use a breakpoint in the code line below to debug your script.
    a = int(input())
    b = (a % 20) + 1
    c = 20 * b - 10
    print(c)

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print_hi()   
    # take the length of the string
    #if the length of the string is even then swap all the elements
    #if the length of the string is odd then swap all the elements except for the middle element

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
