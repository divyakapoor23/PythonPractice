import math


def halloween():
    houses = 3
    if (houses >= 3):
        houses = int(input("Please enter number greater than or equal to 3: "))
    else:
        print("Invalid Input")
    percentage = (2 / houses) * 100
    k = math.ceil(percentage)
    print(k)
