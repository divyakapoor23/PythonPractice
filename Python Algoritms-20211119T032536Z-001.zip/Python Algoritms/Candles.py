def candles():
    f = int(input())
    # each friend needs 9 candles
    # total candles  will be = f + myself * 9
    c = (f + 1) * 9
    print(c)