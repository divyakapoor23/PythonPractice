def gotham():
    c = int(input())
    if(c < 5):
        print("I got this!")
    elif(c <= 10):
        print("Help me Batman")
    else:
        print("Good Luck out there!")
