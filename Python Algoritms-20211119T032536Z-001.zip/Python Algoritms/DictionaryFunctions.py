def dictionary():
    data = {
        'Singapore': 1,
        'Ireland': 6,
        'United Kingdom': 7,
        'Germany': 27,
        'Armenia': 34,
        'United States': 17,
        'Canada': 9,
        'Italy': 74
    }
    a = input("Country name: ")
    if a in data:
        print(data.get(a))
    else:
        print("Not found")