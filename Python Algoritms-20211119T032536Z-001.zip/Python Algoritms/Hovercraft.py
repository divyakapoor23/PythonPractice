def hover():
    sales = int(input())
    cost = 21000000
    sell = 3000000
    price = sales * sell
    if price > cost:
        print("Profit")
    elif price == cost:
        print("Broke Even")
    else:
        print("Loss")