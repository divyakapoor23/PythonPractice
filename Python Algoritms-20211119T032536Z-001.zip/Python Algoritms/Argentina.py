def argentina():
    p = int(input())
    d = int(input())
    c = d * 50
    print(c)
    if c > d:
        print("Pesos")
    else:
        print("Dollars")