def ballPark():
    menu = {"Nachos": 6.00, "Pizza": 6.00, "CheeseBurger": 10.00,
            "Water": 4.00, "Coke": 5.00}
    order = input().split(" ")
    price = 0
    for item in order:
        if item in menu:
            price += menu.get(item, 5)
        else:
            price += menu['Coke']
    finalPrice = price + (price * 7) / 100
    print(finalPrice)

