def terrestrials(lang):
    lang = input("Please enter a string: ")
    print(lang)
    rev = lang[::-1]
    print(rev)
    #reversing a string hello
    #len/2 = k
    
def money(val):
    val = input("Please enter the amount: ")

