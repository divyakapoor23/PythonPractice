def skee():
    points = int(input())
    cost = int(input())
    if points/12 >= cost:
        print("Buy it!")
    else:
        print("Try again")