def land():
    a = int(input())
    fit = 20 #20 people can fit in the boat
    trip = 10 #each way trip time
    if a < 21:
        print("trip")
    else:
        
