def easter():
    eggs = int(input())
    basket = int(input())
    amount = int(input())
    if(basket+amount < eggs):
        print("Candy Time")
    else:
        print("Keep Hunting")