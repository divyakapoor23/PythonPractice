def gaurd():
    length = int(input())
    breadth = int(input())
    totalFlamingoes = length + breadth
    print(totalFlamingoes)