def odd():
    a = input("Size of list: ")
    sum = 0
    while a > 0:
        a = a - 1
        n = input()
        if n%2 == 0:
            sum +=n
    print(sum)

