#Lunh Formula
#reverse number
def creditCard():
    num = input()
    rev = num[::-1]
    print(rev)
    listNum = []
    listNum[:0] = rev
    print(listNum) 
