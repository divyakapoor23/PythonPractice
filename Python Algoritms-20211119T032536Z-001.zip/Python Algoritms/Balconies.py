def balconies():
    a = input()
    b = input()
    aList = list(a.split(","))
    bList = list(b.split(","))
    areaA = int(aList[0]) * int(aList[1])
    areaB = int(bList[0]) * int(bList[1])
    print(areaA)
    print(areaB)
    if areaA > areaB:
        print("Apartment A")
    else:
        print("Apartment B")