def paint():
    c = int(input())
    can = 40
    ac = (c * 5 + can) * 1.1
    k = round(ac)
    print(k)