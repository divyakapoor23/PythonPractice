def ones():
    n = int(input())
    if(n >=1):
        k = n %2
    print(k)