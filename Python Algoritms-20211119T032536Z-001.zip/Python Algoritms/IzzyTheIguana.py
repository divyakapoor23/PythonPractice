def Izzy():
    s = input()
    s = s.split(" ")
    points = 0
    for i in s:
        if i == "Lettuce":
            points += 5
        elif i == "Carrot":
            points += 4
        elif i == "Mango":
            points += 9
        else:
            points += 0
    if points < 10:
        print("Time to wait!")
    else:
        print("Come on Down!")