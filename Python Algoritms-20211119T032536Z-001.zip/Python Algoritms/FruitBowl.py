def fruit():
     f = int(input())
     apples = f / 2
     pies = apples // 3
     print(round(pies))
