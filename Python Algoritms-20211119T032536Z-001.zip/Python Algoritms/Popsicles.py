def popsicles():
    siblings = int(input())
    popsiclesN = int(input())
    if popsiclesN % siblings == 0:
        print("Give them away")
    else:
        print("eat them yourself")