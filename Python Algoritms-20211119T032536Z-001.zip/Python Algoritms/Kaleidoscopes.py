import math
def kaleidoscopes():
    kal = int(input())
    #discount = 10%
    #tax = 7% = 1.07
    cost = 5.00
    if kal > 1:
        total = (cost * kal) * 0.9
    else:
        total = kal * cost
    c = total * 1.07
    c = "{:.2f}".format(cost)
    print(c)

