def cheer():
    yards = int(input())
    if (yards <= 1):
        print("shh")
    elif (yards <= 10):
        print("RA!" * yards)
    elif (yards > 10):
        print("High Five")
    else:
        print("No yards")